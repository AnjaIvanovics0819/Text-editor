﻿namespace PrvaKolokvijumskaNedelja_AnjaIvanovicsS08191
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.rt = new System.Windows.Forms.RichTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuBold = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItalic = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuColor = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuFont = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOpen = new System.Windows.Forms.Button();
            this.mnuSaveAs = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.colorSelect = new System.Windows.Forms.ColorDialog();
            this.fontSelect = new System.Windows.Forms.FontDialog();
            this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.dlgSaveFile = new System.Windows.Forms.SaveFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnPronadjiIZameni = new System.Windows.Forms.Button();
            this.txtPronadji = new System.Windows.Forms.TextBox();
            this.txtZameni = new System.Windows.Forms.TextBox();
            this.ofDialog = new System.Windows.Forms.OpenFileDialog();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rt
            // 
            this.rt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rt.ContextMenuStrip = this.contextMenuStrip1;
            this.rt.Location = new System.Drawing.Point(12, 70);
            this.rt.Name = "rt";
            this.rt.Size = new System.Drawing.Size(786, 382);
            this.rt.TabIndex = 0;
            this.rt.Text = "";
            this.rt.LinkClicked += new System.Windows.Forms.LinkClickedEventHandler(this.rt_LinkClicked);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuBold,
            this.mnuItalic,
            this.mnuColor,
            this.toolStripMenuItem1,
            this.mnuFont});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(152, 106);
            // 
            // mnuBold
            // 
            this.mnuBold.Name = "mnuBold";
            this.mnuBold.Size = new System.Drawing.Size(151, 24);
            this.mnuBold.Text = "Font Bold";
            this.mnuBold.Click += new System.EventHandler(this.mnuBold_Click);
            // 
            // mnuItalic
            // 
            this.mnuItalic.Name = "mnuItalic";
            this.mnuItalic.Size = new System.Drawing.Size(151, 24);
            this.mnuItalic.Text = "Font Italic";
            this.mnuItalic.Click += new System.EventHandler(this.mnuItalic_Click);
            // 
            // mnuColor
            // 
            this.mnuColor.Name = "mnuColor";
            this.mnuColor.Size = new System.Drawing.Size(151, 24);
            this.mnuColor.Text = "Font Color";
            this.mnuColor.Click += new System.EventHandler(this.mnuColor_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(148, 6);
            // 
            // mnuFont
            // 
            this.mnuFont.Name = "mnuFont";
            this.mnuFont.Size = new System.Drawing.Size(151, 24);
            this.mnuFont.Text = "Select Font";
            this.mnuFont.Click += new System.EventHandler(this.mnuFont_Click);
            // 
            // mnuOpen
            // 
            this.mnuOpen.Location = new System.Drawing.Point(12, 12);
            this.mnuOpen.Name = "mnuOpen";
            this.mnuOpen.Size = new System.Drawing.Size(129, 52);
            this.mnuOpen.TabIndex = 1;
            this.mnuOpen.Text = "Otvori fajl";
            this.mnuOpen.UseVisualStyleBackColor = true;
            this.mnuOpen.Click += new System.EventHandler(this.mnuOpen_Click);
            // 
            // mnuSaveAs
            // 
            this.mnuSaveAs.Location = new System.Drawing.Point(516, 12);
            this.mnuSaveAs.Name = "mnuSaveAs";
            this.mnuSaveAs.Size = new System.Drawing.Size(104, 52);
            this.mnuSaveAs.TabIndex = 2;
            this.mnuSaveAs.Text = "Snimi fajl";
            this.mnuSaveAs.UseVisualStyleBackColor = true;
            this.mnuSaveAs.Click += new System.EventHandler(this.mnuSaveAs_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(683, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(92, 52);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Zavrsi program";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dlgOpenFile
            // 
            this.dlgOpenFile.FileName = "openFileDialog1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(188, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Pronadji:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(188, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Zameni sa:";
            // 
            // btnPronadjiIZameni
            // 
            this.btnPronadjiIZameni.Location = new System.Drawing.Point(384, 6);
            this.btnPronadjiIZameni.Name = "btnPronadjiIZameni";
            this.btnPronadjiIZameni.Size = new System.Drawing.Size(92, 58);
            this.btnPronadjiIZameni.TabIndex = 6;
            this.btnPronadjiIZameni.Text = "Pronadji i zameni";
            this.btnPronadjiIZameni.UseVisualStyleBackColor = true;
            this.btnPronadjiIZameni.Click += new System.EventHandler(this.btnPronadjiIZameni_Click);
            // 
            // txtPronadji
            // 
            this.txtPronadji.Location = new System.Drawing.Point(266, 9);
            this.txtPronadji.Name = "txtPronadji";
            this.txtPronadji.Size = new System.Drawing.Size(100, 22);
            this.txtPronadji.TabIndex = 7;
            // 
            // txtZameni
            // 
            this.txtZameni.Location = new System.Drawing.Point(266, 45);
            this.txtZameni.Name = "txtZameni";
            this.txtZameni.Size = new System.Drawing.Size(100, 22);
            this.txtZameni.TabIndex = 8;
            // 
            // ofDialog
            // 
            this.ofDialog.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtZameni);
            this.Controls.Add(this.txtPronadji);
            this.Controls.Add(this.btnPronadjiIZameni);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.mnuSaveAs);
            this.Controls.Add(this.mnuOpen);
            this.Controls.Add(this.rt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rt;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuBold;
        private System.Windows.Forms.ToolStripMenuItem mnuItalic;
        private System.Windows.Forms.ToolStripMenuItem mnuColor;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mnuFont;
        private System.Windows.Forms.Button mnuOpen;
        private System.Windows.Forms.Button mnuSaveAs;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ColorDialog colorSelect;
        private System.Windows.Forms.FontDialog fontSelect;
        private System.Windows.Forms.OpenFileDialog dlgOpenFile;
        private System.Windows.Forms.SaveFileDialog dlgSaveFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnPronadjiIZameni;
        private System.Windows.Forms.TextBox txtPronadji;
        private System.Windows.Forms.TextBox txtZameni;
        private System.Windows.Forms.OpenFileDialog ofDialog;
    }
}

