﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PrvaKolokvijumskaNedelja_AnjaIvanovicsS08191
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mnuBold_Click(object sender, EventArgs e)
        {
            Font f = rt.SelectionFont;
            if (f.Bold == true)
            {
                rt.SelectionFont = new Font(f.FontFamily, f.Size, FontStyle.Regular);
            }
            else
            {
                rt.SelectionFont = new Font(f.FontFamily, f.Size, FontStyle.Bold);

            }
        }

        private void mnuItalic_Click(object sender, EventArgs e)
        {
            Font f = rt.SelectionFont;
            if (f.Italic == true)
            {
                rt.SelectionFont = new Font(f.FontFamily, f.Size, FontStyle.Regular);
            }
            else
            {
                rt.SelectionFont = new Font(f.FontFamily, f.Size, FontStyle.Italic);

            }
        }

        private void mnuFont_Click(object sender, EventArgs e)
        {
            if (fontSelect.ShowDialog() == DialogResult.Cancel) return;

            Font f = fontSelect.Font;
            rt.SelectionFont = f;
        }

        private void mnuColor_Click(object sender, EventArgs e)
        {
            Color cs = rt.SelectionColor;
            if (colorSelect.ShowDialog() == DialogResult.Cancel) return;
            Color c = colorSelect.Color;
            rt.SelectionColor = c;
        }

        private void mnuOpen_Click(object sender, EventArgs e)
        {
            dlgOpenFile.Title = "Otvori rtf fajl";
            dlgOpenFile.Filter = "rtf files|*.rtf|all files| *.*";
            dlgOpenFile.InitialDirectory = Application.StartupPath;
            if (dlgOpenFile.ShowDialog() == DialogResult.Cancel) return;

            try
            {
                rt.LoadFile(dlgOpenFile.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Greska", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void mnuSaveAs_Click(object sender, EventArgs e)
        {
            dlgSaveFile.Title = "Snimi rtf fajl";
            dlgSaveFile.DefaultExt = "rtf";
            dlgSaveFile.Filter = "rtf files|*.rtf|all files| *.*";
            dlgOpenFile.InitialDirectory = Application.StartupPath;

            if (dlgSaveFile.ShowDialog() == DialogResult.Cancel) return;
            rt.SaveFile(dlgSaveFile.FileName, RichTextBoxStreamType.RichText);

            MessageBox.Show("Snimljen fajl");
        }

        private void rt_LinkClicked(object sender, LinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(e.LinkText);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public string ZamenaTeksta(string Stari, string Novi, string Putanja)
        {



            try
            {
                StreamReader sr = new StreamReader(Putanja);
                String Sadrzaj = sr.ReadToEnd();
                sr.Close();
                Sadrzaj = Sadrzaj.Replace(Stari, Novi);
                StreamWriter sw = new StreamWriter(Putanja);
                sw.Write(Sadrzaj);
                sw.Flush();
                sw.Close();
                return Sadrzaj;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska!");
                return " ";
            }

        }

        private void btnPronadjiIZameni_Click(object sender, EventArgs e)
        {
            dlgOpenFile.Title = "Otvori fajl";
            dlgOpenFile.Filter = "Txt fajlovi|*.txt*";
            if (dlgOpenFile.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }
            rt.Text = ZamenaTeksta(txtPronadji.Text, txtZameni.Text, dlgOpenFile.FileName);
        }

        bool sacuvaj(string ime, string sadrzaj)
        {
            try
            {
                rt.SaveFile(ime, RichTextBoxStreamType.RichText);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Greska", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

        }

        void open(string ime)
        {
            try
            {
                rt.LoadFile(ime);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Greska", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // if(e.KeyCode == Keys.Escape)
            //{
              //btnExit_Click(null, null);

            //  }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }
    }
}
